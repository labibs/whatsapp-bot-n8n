# whatsapp-bot-n8n
Whatsapp Bot dengan baileys dan integrasi n8n
